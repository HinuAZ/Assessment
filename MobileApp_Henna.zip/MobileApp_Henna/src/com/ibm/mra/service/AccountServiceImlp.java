package com.ibm.mra.service;

import com.ibm.mra.bean.Account;
import com.ibm.mra.dao.*;


public abstract class AccountServiceImlp implements AccountService {

	AccountDao dao;


		  public Account getAccountDetails(String mobileNo) {
			
			return dao.viewBalance(mobileNo);
		}



		public boolean rechargeAccount(int acc_check, int amount) {
			
			return dao.depositAmount(acc_check,amount);
		}


	}

	
	
	
	
	
	
}
