package com.ibm.mra.service;

import java.util.Map;

import com.ibm.mra.bean.Account;

public interface AccountService {
	
	
	Account getAccountDetails(String mobileNo);
	int rechargeAccount(String mobileno,double rechargeAmount);
	boolean getAccountNumber(int acc_check);
	String viewBalance(int acc_check);
}


