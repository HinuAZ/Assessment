package com.ibm.mra.ui;

import java.util.Scanner;

import com.ibm.mra.bean.Account;


public class Main {
	public static void main(String[] args) {
		;
		Account acc = new Account(null, null, 0);
		Scanner sc = new Scanner(System.in);
		int quit = 0;
		int userchoice;
		String customer_name = null;
		while (quit == 0) {
			System.out.println("Enter your choice:");
			System.out.println("1. View Balance \n" + "2. Deposit Amount \n"+"3. Exit Application");
			userchoice = sc.nextInt();
			sc.nextLine();
			switch (userchoice) {
						case 1:
				while (true) {
					System.out.println("Enter the Mobile number to check balance:");
					int acc_check = sc.nextInt();
					if (acc.getAccountNumber(acc_check)) {

						System.out.println("Current balance in your account is :: " + acc.viewBalance(acc_check));
					} else
						System.out.println("INVALID RECORD!");

					break;
				}
				continue;

			case 2:
				while (true) {
					System.out.println("Enter the Account number to deposit money");
					int acc_check = sc.nextInt();
					if (acc.getAccountNumber(acc_check)) {
						System.out.println("Enter the Amount");
						int amount = sc.nextInt();
						boolean depoistamount = acc.depositAmount(acc_check, amount);
						if (depoistamount) {
							System.out.println("The Amount is Deposited Sucessfully");
							System.out.println("Current balance in your account after deposit is = "
									+ acc.viewBalance(acc_check));
						}
					} else
						System.out.println("INVALID RECORD");

					break;
				}
			
				case 3:
				quit = 1;
				System.out.println("Successful logout from the application");

				break;
			}
		}

	}

}
