package com.ibm.mra.bean;

public class Account {

	private String customer_name;
	private String acc_typ;

	 private int acc_no;
	 private double balance;
	
	 public Account(String string, String string2, int i) {
	}

	public void Account(String customer_name, String acc_typ,double balance ) {
		 this.customer_name = customer_name;
		 //this.acc_no = acc_no;
		 this.balance = balance;
		 this.acc_typ=acc_typ;
	 }
	 
	 public int getacc_no() {
			return acc_no;
		}

		public void setacc_no(int acc_no) {
			this.acc_no = acc_no;
		}
		
		public void setacc_typ() {
			this.acc_typ = acc_typ;
		}

		public String getcustomer_name() {
			return customer_name;
		}
		
		public String getacc_typ() {
			return acc_typ;
		}

		public void setcustomer_name(String customer_name) {
			this.customer_name = customer_name;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

		public boolean getAccountNumber(int acc_check) {
			return false;
		}

		public String viewBalance(int acc_check) {
			return null;
		}

		public boolean depositAmount(int acc_check, int amount) {
			return false;
		}

		
		


}
	
	

